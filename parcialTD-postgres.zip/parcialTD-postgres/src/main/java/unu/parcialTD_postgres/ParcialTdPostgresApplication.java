package unu.parcialTD_postgres;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParcialTdPostgresApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParcialTdPostgresApplication.class, args);
	}

}
