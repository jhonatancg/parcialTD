package unu.parcialTD_postgres;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParcialTdPostgresApplicationTests {

	@Test
	void contextLoads() {
	}

}
