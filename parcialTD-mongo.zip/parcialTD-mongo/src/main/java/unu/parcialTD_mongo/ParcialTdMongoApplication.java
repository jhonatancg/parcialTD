package unu.parcialTD_mongo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParcialTdMongoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParcialTdMongoApplication.class, args);
	}

}
